import cv2
import numpy as np
import pandas as pd


def image_extract_info(path, image):
    info = []
    contours, hierarchy = cv2.findContours(image, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    contour_count = len(contours)
    
    contour_max_area = 0
    contour_max_index = 0
    for index in range(0, contour_count):
        contour_area = cv2.contourArea(contours[index])
        if contour_area > contour_max_area:
            contour_max_area = contour_area
            contour_max_index = index
    

    min_box = cv2.minAreaRect(contours[contour_max_index])
    min_box_width = min_box[1][0]
    min_box_height = min_box[1][1]
    if min_box_width > min_box_height:
        temp = min_box_width
        min_box_width = min_box_height
        min_box_height = temp
    
    # min_box raito
    min_box_area = min_box_width * min_box_height
    min_box_raito = min_box_height / min_box_width

    # contour area / minbox area
    contour_area = cv2.contourArea(contours[contour_max_index])
    contour_area_per_min_box_area = int(100 * contour_area / min_box_area)

    # white point / contour area
    mask = image
    white_point_count = cv2.countNonZero(image)
    white_per_contour = int(100 * white_point_count / contour_area)
    if white_per_contour > 100:
        white_per_contour = 100

    # white point / min_box
    white_per_box = int(100 * white_point_count / min_box_area)

    
    # contour inside
    contour_inside = [0,0]
    for index in range(0, contour_count):
        if index == contour_max_index:
            continue
        parent = hierarchy[0][index][3]
        if parent != contour_max_index:
            continue
        inside_box = cv2.boundingRect(contours[index])
        inside_box_height = inside_box[3]
        if inside_box_height < (min_box_height / 8 ):
            continue
        
        image_height = image.shape[0]
        contour_inside_center_y = cv2.minAreaRect(contours[index])[0][1]
        contour_inside_center_pos = contour_inside_center_y / image_height
        if contour_inside_center_pos < 0.5:
            contour_inside[0] = contour_inside_center_pos
        else:
            contour_inside[1] = contour_inside_center_pos

    # contour size / min box
    contour_point = len(contours[contour_max_index])
    contour_point_per_box = int(100 * contour_point / white_point_count)
    # print(contour_point_per_box)

    
    
    # mean
    mean = int(cv2.mean(image)[0])

    info.append(contour_inside[0])
    info.append(contour_inside[1])
    info.append(white_per_contour)
    info.append(white_per_box)
    info.append(mean)
    # info.append(contour_point_per_box)
    # info.append(contour_area_per_min_box_area)
    return info
    pass
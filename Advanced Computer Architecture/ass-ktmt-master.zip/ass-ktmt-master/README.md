# Bài tập lớn kiến trúc máy tính
## Bài tập lớn được viết trên phần mềm [Mars4_5](http://courses.missouristate.edu/KenVollmar/mars/)
## Đề bài
Viết chương trình sắp xếp chuỗi số thực 20 phần tử nhập từ bàn phím dùng giải thuật Quick sort. Yêu cầu xuất kết quả từng bước chạy ra màn hình.
